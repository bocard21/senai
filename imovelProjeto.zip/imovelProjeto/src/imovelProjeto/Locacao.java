package imovelProjeto;

import java.util.Date;

public class Locacao {
    private Date dataInicio;
    private Date dataTermino;
    private Date dataPagamento;
    private Locatario locatario;
    private Imovel imovel;
    private Corretor corretor;
   

    public Locacao(Date dataInicio, Date dataTermino, Date dataPagamento, Locatario locatario, Imovel imovel, Corretor corretor, Proprietario proprietario) {
        this.dataInicio = dataInicio;
        this.dataTermino = dataTermino;
        this.dataPagamento = dataPagamento;
        this.locatario = locatario;
        this.imovel = imovel;
        this.corretor = corretor;
        
    }

    public void enviarCobranca() {
        // Implementação para enviar cobrança
        System.out.println("E-mail: " + locatario.getEmail());
        System.out.println("O valor referente ao seu aluguel neste mês foi de R$" + imovel.calcularAluguel());
    }

    public void pagarProprietario() {
        double valorLiquido = imovel.calcularAluguel();
        corretor.receber(corretor.getComissao());
        
    }
}