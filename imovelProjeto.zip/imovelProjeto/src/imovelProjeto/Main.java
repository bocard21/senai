package imovelProjeto;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Crie instâncias de Corretor, Proprietario, Locatario, Casa e Apartamento
        Corretor corretor = new Corretor("João", "123-456-7890", "Rua A", "123456789", "C123", new Date(), 0.10);
        Proprietario proprietario = new Proprietario("Maria", "987-654-3210", "Rua B", "987654321", "789012", "A789");
        Locatario locatario = new Locatario("", "", "", "", "joao@email.com", "5000"); // Campos de nome, telefone, endereço e CPF estão vazios
        Casa casa = new Casa(1, "Rua X", 1500, 2, 3, 2, 2);
        Apartamento apartamento = new Apartamento(2, "Rua Y", 1200, 1, 2, 1, 5, 501, 300, 50, 100);

        // Cálculo do aluguel
        double aluguelCasa = casa.calcularAluguel();
        double aluguelApartamento = apartamento.calcularAluguel();

        System.out.println("Aluguel da casa: R$" + aluguelCasa);
        System.out.println("Aluguel do apartamento: R$" + aluguelApartamento);

        // Criação de uma locação
        Date dataInicio = new Date();
        Date dataTermino = new Date();
        Date dataPagamento = new Date();

        Locacao locacao = new Locacao(dataInicio, dataTermino, dataPagamento, locatario, casa, corretor, proprietario);

        // Enviar cobrança e pagar proprietário
        locacao.enviarCobranca();
        locacao.pagarProprietario();
    }
}