package imovelProjeto;

import java.util.Date;

public class Corretor extends Pessoa implements ReceberValor {
    private String registro;
    private Date dataAdmissao;
    private double comissao;
    private double totalComissaoAcumulada;

    public Corretor(String nome, String telefone, String endereco, String cpf, String registro, Date dataAdmissao, double comissao) {
        super(nome, telefone, endereco, cpf);
        this.registro = registro;
        this.dataAdmissao = dataAdmissao;
        this.comissao = comissao;
        this.totalComissaoAcumulada = 0.0;
    }

    public String getRegistro() {
        return registro;
    }

    public Date getDataAdmissao() {
        return dataAdmissao;
    }

    public double getComissao() {
        return comissao;
    }

    public double getTotalComissaoAcumulada() {
        return totalComissaoAcumulada;
    }

    public void sacarComissoes(double valor) {
        totalComissaoAcumulada -= valor;
    }

    @Override
    public void receber(double valor) {
        System.out.println("O corretor " + getNome() + " está recebendo o valor de R$" + valor);
        totalComissaoAcumulada += valor;
    }
}
