package imovelProjeto;

public abstract class Imovel {
    private int codigo;
    private String endereco;
    private double valorLocacao;
    private int vagasGaragem;
    private int quartos;
    private int banheiros;
    private Proprietario proprietario;
    

	public Imovel(int codigo, String endereco, double valorLocacao, int vagasGaragem, int quartos, int banheiros, Proprietario proprietario) {
        this.codigo = codigo;
        this.endereco = endereco;
        this.valorLocacao = valorLocacao;
        this.vagasGaragem = vagasGaragem;
        this.quartos = quartos;
        this.banheiros = banheiros;
        this.proprietario = proprietario;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getEndereco() {
        return endereco;
    }

    public double getValorLocacao() {
        return valorLocacao;
    }

    public int getVagasGaragem() {
        return vagasGaragem;
    }

    public int getQuartos() {
        return quartos;
    }

    public int getBanheiros() {
        return banheiros;
    }
    
    public Proprietario getProprietario() {
		return proprietario;
	}

	public void setProprietario(Proprietario proprietario) {
		this.proprietario = proprietario;
	}

   
    public abstract double calcularAluguel();
}
